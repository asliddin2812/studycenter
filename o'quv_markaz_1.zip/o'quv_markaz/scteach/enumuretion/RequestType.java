package com.backend.studycenter.scteach.enumuretion;

public enum RequestType {
    MEETING,
    CHAT,
    GROUP_MEETING
}
