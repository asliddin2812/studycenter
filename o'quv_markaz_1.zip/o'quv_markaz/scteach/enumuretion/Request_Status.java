package com.backend.studycenter.scteach.enumuretion;

public enum Request_Status {
    READ,
    UNREAD,
    ALL_REQUEST
}
