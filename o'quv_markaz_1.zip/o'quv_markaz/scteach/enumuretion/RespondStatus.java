package com.backend.studycenter.scteach.enumuretion;

public enum RespondStatus {
    Read,
    UnRead,
    AllMessages
}
